<div class="mini-submenu">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </div>
    <div class="list-group">
        <a href="edit-page-verify-1.php" class="list-group-item">
             Semakan Kelayakan Pemohonan
        </a>
        <a href="edit-page-verify-2.php" class="list-group-item">
             Butiran Kelayakan Akademik
        </a>
        <a href="edit-page-verify-3.php" class="list-group-item">
             Butiran Kegiatan Dan Tanggungjawab Di Sekolah
        </a>
        <a href="edit-page-verify-4.php" class="list-group-item">
            Pencapaian Bidang Al-Quran Dan Maklumat Ibu/Bapa/Penjaga 
        </a>
        <a href="edit-page-verify-5.php" class="list-group-item">
            Pemohonan Asrama Dan Muat Naik Fail
        </a>
    </div>       