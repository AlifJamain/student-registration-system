<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "spp";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>