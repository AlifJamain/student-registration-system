<!---<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-3">
    <div class="container">
        <a href="#" class="navbar-brand mr-3">BPIJAINJ</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active">Halaman Utama</a>
                <a href="edit-page-verify-1.php" class="nav-item nav-link">Kemaskini Permohonan</a>
            </div>
        </div>
    </div>
</nav>--->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">BPIJAINJ</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Maklumat Sekolahs<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Maklumat Sekolah</a></li>
          <li><a href="#">Manual Pengguna</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li>
      <li><a href="#">Manual Pengguna</a></li>
      </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="daftar-pengguna.php"><span class="glyphicon glyphicon-user"></span> Daftar Pengguna</a></li>
      <li><a href="index.php"><span class="glyphicon glyphicon-log-in"></span> Log Masuk</a></li>
    </ul>
  </div>
</nav>